#pragma once
// Set your own values locally. Never publish the filled file.
const char* HOME_SSID = "YOUR_WIFI_2_4_GHZ";
const char* HOME_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec";
// Generate your own random secret of at least 32 characters.
// Use the identical value in the Apps Script POWERWATCH_SECRET property.
const char* GOOGLE_SECRET = "REPLACE_WITH_RANDOM_SECRET_AT_LEAST_32_CHARS";
