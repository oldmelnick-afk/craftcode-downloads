// PowerWatch public preparation 2026-09-08. See README for provenance and test limits.
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

// =====================================================
// POWERWATCH - AUTO MODE
// ESP32 starts monitoring immediately after power-up.
// 0..2 visible networks = keep waiting.
// The calibrated Wi-Fi threshold is only an indirect mains-restoration indicator.
// After detection, Wi-Fi scanning stops and the ESP32 retries
// the Google Apps Script notification until HTTP 200 + OK_SENT / OK_DUPLICATE.
// =====================================================

#include "config.h"
#include "google_roots.h"
#include <esp_system.h>
#include <time.h>

const int MIN_RSSI = -85;
const int TRIGGER_NETWORK_COUNT = 3;

const unsigned long SCAN_INTERVAL_MS = 5000;
const unsigned long MAIL_RETRY_MS = 15000;
const unsigned long WIFI_RECONNECT_MS = 5000;
const unsigned long MAIL_FIRST_DELAY_MS = 3000;

WebServer server(80);

enum PowerWatchState {
  MONITORING,
  POWER_BACK
};

PowerWatchState state = MONITORING;

int visibleNetworks = 0;
int homeRssi = 0;

bool mailSent = false;
unsigned long mailAttempts = 0;
int lastHttpCode = 0;
String lastHttpBody = "";
String activeEventId;

String newEventId() {
  char id[33];
  snprintf(id, sizeof(id), "%08lx%08lx%08lx%08lx",
    (unsigned long)esp_random(), (unsigned long)esp_random(),
    (unsigned long)esp_random(), (unsigned long)esp_random());
  return String(id);
}

unsigned long lastScanMs = 0;
unsigned long lastMailAttemptMs = 0;
unsigned long lastReconnectMs = 0;
unsigned long powerBackMs = 0;

// =====================================================
// URL ENCODE
// =====================================================

String urlEncode(const String& input) {
  const char hex[] = "0123456789ABCDEF";
  String out = "";

  for (size_t i = 0; i < input.length(); i++) {
    uint8_t c = (uint8_t)input[i];

    bool safe =
      (c >= 'a' && c <= 'z') ||
      (c >= 'A' && c <= 'Z') ||
      (c >= '0' && c <= '9') ||
      c == '-' || c == '_' || c == '.' || c == '~';

    if (safe) {
      out += (char)c;
    } else {
      out += '%';
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }

  return out;
}

// =====================================================
// WIFI SCAN
// =====================================================

void scanNetworks() {
  Serial.println();
  Serial.println("Scanning Wi-Fi...");

  int found = WiFi.scanNetworks();
  visibleNetworks = 0;

  if (found > 0) {
    for (int i = 0; i < found; i++) {
      String ssid = WiFi.SSID(i);
      int rssi = WiFi.RSSI(i);

      // Do not count the Wi-Fi network used by the ESP32 itself.
      if (ssid == HOME_SSID) {
        continue;
      }

      // Ignore very weak / unstable networks.
      if (rssi < MIN_RSSI) {
        continue;
      }

      visibleNetworks++;

      Serial.print(ssid);
      Serial.print(" | ");
      Serial.print(rssi);
      Serial.println(" dBm");
    }
  }

  WiFi.scanDelete();
  homeRssi = WiFi.RSSI();

  Serial.print("Visible networks: ");
  Serial.println(visibleNetworks);

  Serial.print("Trigger threshold: ");
  Serial.println(TRIGGER_NETWORK_COUNT);

  Serial.print("Home Wi-Fi RSSI: ");
  Serial.print(homeRssi);
  Serial.println(" dBm");

  if (state == MONITORING && visibleNetworks >= TRIGGER_NETWORK_COUNT) {
    activeEventId = newEventId();
    state = POWER_BACK;
    powerBackMs = millis();
    lastMailAttemptMs = 0;

    Serial.println();
    Serial.println("================================");
    Serial.println("POWER BACK DETECTED");
    Serial.println("Wi-Fi scanning is now stopped.");
    Serial.println("Notification retries will continue until success.");
    Serial.println("================================");
  }
}

// =====================================================
// GOOGLE APPS SCRIPT EMAIL
// =====================================================

bool sendMailNotification(const String& requestEventId) {
  mailAttempts++;

  Serial.println();
  Serial.print("Mail attempt #");
  Serial.println(mailAttempts);

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Mail: home Wi-Fi is disconnected");
    lastHttpCode = -1000;
    lastHttpBody = "Wi-Fi disconnected";
    return false;
  }

  if (time(nullptr) < 1700000000) {
    lastHttpCode = -1002;
    lastHttpBody = "Waiting for NTP time for certificate verification";
    return false;
  }

  String url = String(GOOGLE_SCRIPT_URL);
  url += "?key=";
  url += urlEncode(String(GOOGLE_SECRET));
  url += "&networks=";
  url += String(visibleNetworks);
  url += "&event=";
  url += urlEncode(requestEventId);

  WiFiClientSecure client;
  client.setCACert(GOOGLE_ROOTS);
  client.setTimeout(15000);

  HTTPClient http;

  Serial.println("Mail: opening Google Apps Script...");

  if (!http.begin(client, url)) {
    Serial.println("Mail: HTTP begin failed");
    lastHttpCode = -1001;
    lastHttpBody = "HTTP begin failed";
    return false;
  }

  // Google Apps Script web apps normally redirect to googleusercontent.com.
  http.setFollowRedirects(HTTPC_FORCE_FOLLOW_REDIRECTS);
  http.setTimeout(15000);
  http.setReuse(false);

  int code = http.GET();
  lastHttpCode = code;

  String body = "";
  if (code > 0) {
    body = http.getString();
    body.trim();
  }

  lastHttpBody = body;

  Serial.print("Mail HTTP code: ");
  Serial.println(code);

  Serial.print("Mail response: ");
  Serial.println(body);

  http.end();

  if (code == HTTP_CODE_OK && (body == "OK_SENT" || body == "OK_DUPLICATE")) {
    Serial.println("MAIL SENT SUCCESSFULLY");
    return true;
  }

  Serial.println("Mail failed. Will retry automatically.");
  return false;
}

// =====================================================
// HTML
// =====================================================

String makePage() {
  String html = "";

  html += "<!doctype html>";
  html += "<html lang='ru'>";
  html += "<head>";
  html += "<meta charset='utf-8'>";
  html += "<meta name='viewport' content='width=device-width,initial-scale=1,viewport-fit=cover'>";
  html += "<meta http-equiv='refresh' content='3'>";
  html += "<meta name='apple-mobile-web-app-capable' content='yes'>";
  html += "<meta name='theme-color' content='#000000'>";
  html += "<title>PowerWatch</title>";

  html += "<style>";
  html += "*{box-sizing:border-box}";
  html += "body{margin:0;font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;text-align:center}";
  html += ".dark{min-height:100vh;background:#000;color:#fff;padding:55px 28px 35px;display:flex;flex-direction:column}";
  html += ".light{min-height:100vh;background:#fff;color:#000;padding:55px 28px 35px;display:flex;flex-direction:column;justify-content:center}";
  html += "h1{font-size:38px;margin:7vh 0 0}";
  html += ".num{font-size:150px;font-weight:800;margin-top:7vh}";
  html += ".sub{font-size:25px;margin-top:20px}";
  html += ".state{font-size:20px;color:#999;line-height:1.5;margin-top:45px}";
  html += ".small{font-size:16px;color:#777;line-height:1.5;margin-top:18px}";
  html += ".spacer{flex:1}";
  html += ".bolt{font-size:90px}";
  html += ".alertTitle{font-size:38px;font-weight:800;line-height:1.15;margin-top:25px}";
  html += ".alertText{font-size:22px;line-height:1.45;margin-top:45px}";
  html += ".ok{font-size:20px;font-weight:700;margin-top:35px}";
  html += "</style>";
  html += "</head>";
  html += "<body>";

  if (state == MONITORING) {
    html += "<div class='dark'>";
    html += "<h1>POWER WATCH</h1>";
    html += "<div class='num'>";
    html += String(visibleNetworks);
    html += "</div>";
    html += "<div class='sub'>Wi-Fi сетей вокруг</div>";
    html += "<div class='state'>Мониторинг включён автоматически.<br>Ждём 3 или больше сетей.</div>";
    html += "<div class='small'>ESP32 - роутер: ";
    html += String(homeRssi);
    html += " dBm</div>";
    html += "<div class='spacer'></div>";
    html += "</div>";
  } else {
    html += "<div class='light'>";
    html += "<div class='bolt'>⚡</div>";
    html += "<div class='alertTitle'>ПОЯВИЛИСЬ<br>WI-FI СЕТИ</div>";
    html += "<div class='alertText'>Обнаружено Wi-Fi сетей: ";
    html += String(visibleNetworks);
    html += "<br><br>Возможно, городская сеть восстановилась. Подтверди это штатным индикатором; устройство не измеряет напряжение.</div>";

    if (mailSent) {
      html += "<div class='ok'>✓ Письмо отправлено</div>";
    } else {
      html += "<div class='ok'>Ожидаем интернет / отправку письма...</div>";
      html += "<div class='small'>Попыток: ";
      html += String(mailAttempts);
      html += "<br>Последний HTTP: ";
      html += String(lastHttpCode);
      html += "</div>";
    }

    html += "</div>";
  }

  html += "<form method='post' action='/testmail'><button type='submit'>Отправить тестовое письмо</button></form>";
  html += "</body>";
  html += "</html>";

  return html;
}

void handleRoot() {
  server.send(
    200,
    "text/html; charset=utf-8",
    makePage()
  );
}

// Manual test: use the button on the local status page (POST).
void handleTestMail() {
  bool ok = sendMailNotification("test-" + newEventId());

  String result = ok
    ? "OK - mail sent"
    : "FAILED - will retry in normal alarm mode";

  result += "\nHTTP: ";
  result += String(lastHttpCode);
  result += "\nBody: ";
  result += lastHttpBody;

  server.send(
    ok ? 200 : 500,
    "text/plain; charset=utf-8",
    result
  );
}

// =====================================================
// SETUP
// =====================================================

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println();
  Serial.println("=== POWER WATCH AUTO ===");
  Serial.println("Monitoring starts automatically after power-up.");

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);

  WiFi.begin(HOME_SSID, HOME_PASSWORD);
  configTime(0, 0, "time.google.com", "pool.ntp.org");

  Serial.print("Connecting to home Wi-Fi");

  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }

  Serial.println();
  Serial.print("Connected. IP: ");
  Serial.println(WiFi.localIP());

  if (MDNS.begin("powerwatch")) {
    Serial.println("Open: http://powerwatch.local");
    Serial.println("Mail test: use the button on the local status page");
  } else {
    Serial.println("mDNS failed. Use the IP address above.");
  }

  server.on("/", HTTP_GET, handleRoot);
  server.on("/testmail", HTTP_POST, handleTestMail);
  server.begin();

  Serial.println("Web server started.");

  // Monitoring starts immediately.
  scanNetworks();
  lastScanMs = millis();
}

// =====================================================
// LOOP
// =====================================================

void loop() {
  server.handleClient();

  unsigned long now = millis();

  // Keep trying to reconnect to the generator-powered home router.
  if (WiFi.status() != WL_CONNECTED) {
    if (now - lastReconnectMs >= WIFI_RECONNECT_MS) {
      lastReconnectMs = now;

      Serial.println("Home Wi-Fi disconnected. Reconnecting...");
      WiFi.reconnect();
    }
  }

  // Before mains recovery: keep scanning.
  if (state == MONITORING) {
    if (now - lastScanMs >= SCAN_INTERVAL_MS) {
      lastScanMs = now;
      scanNetworks();
    }
  }

  // Refresh the clock after the blocking scan to avoid unsigned underflow.
  now = millis();

  // After the threshold is reached: never scan again.
  // Retry the email FOREVER until Google confirms success.
  if (state == POWER_BACK && !mailSent) {
    bool firstDelayPassed =
      now - powerBackMs >= MAIL_FIRST_DELAY_MS;

    bool retryDue =
      lastMailAttemptMs == 0 ||
      now - lastMailAttemptMs >= MAIL_RETRY_MS;

    if (firstDelayPassed && retryDue) {
      mailSent = sendMailNotification(activeEventId);
      lastMailAttemptMs = millis();
    }
  }

  delay(5);
}
