/* PowerWatch public preparation 2026-09-08.
 * In Project Settings > Script Properties set:
 * EMAIL_TO = your recipient address
 * POWERWATCH_SECRET = your own random secret, at least 32 characters
 * Use the same secret in the ESP32 config.h. Keep it private.
 */
function doGet(e) {
  const props = PropertiesService.getScriptProperties();
  const secret = props.getProperty('POWERWATCH_SECRET') || '';
  const email = props.getProperty('EMAIL_TO') || '';
  const p = (e && e.parameter) || {};
  const reply = value => ContentService.createTextOutput(value);
  if (secret.length < 32 || secret.startsWith('REPLACE_') || !email) return reply('NOT_CONFIGURED');
  if ((p.key || '') !== secret) return reply('DENIED');
  const eventId = p.event || '';
  if (!/^(test-)?[0-9a-f]{32}$/.test(eventId)) return reply('INVALID_EVENT');
  const networks = Number(p.networks);
  if (!Number.isInteger(networks) || networks < 0 || networks > 10000) return reply('INVALID_NETWORKS');
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) return reply('RETRY_BUSY');
  try {
    // Keep recent IDs so an intervening manual test does not erase an alarm ID.
    const ids = JSON.parse(props.getProperty('POWERWATCH_RECENT_EVENTS') || '[]');
    if (ids.includes(eventId)) return reply('OK_DUPLICATE');
    const test = eventId.startsWith('test-');
    MailApp.sendEmail({
      to: email,
      subject: test ? 'PowerWatch: тест уведомления' : 'PowerWatch: появились Wi-Fi сети',
      body: (test ? 'Тест канала ESP32 → Apps Script → почта.' :
        'Достигнут настроенный порог Wi-Fi сетей. Возможно, городское питание восстановилось.') +
        '\n\nУчтено Wi-Fi точек: ' + networks +
        '\n\nPowerWatch не измеряет напряжение. Подтвердите наличие питания штатным индикатором. Устройство не управляет переключением источников питания.',
      name: 'PowerWatch'
    });
    ids.push(eventId);
    props.setProperty('POWERWATCH_RECENT_EVENTS', JSON.stringify(ids.slice(-128)));
    return reply('OK_SENT');
  } finally {
    lock.releaseLock();
  }
}
